import UIKit


//MARK: Optional Chaningn:

let optionalChainingArray = ["Ahmet", "Alex", "Marcus","Marie", "Natalie","Ayla", "Marcus"]
let object = optionalChainingArray.firstIndex(of: "Marcus")?.description.uppercased()




